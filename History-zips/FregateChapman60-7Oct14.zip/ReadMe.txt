Product: Fregate Chapman 40, October 2014

Designer: Emmanuel Patoux

Support:  http://forums.obrary.com/category/designs/fregate-chapman-40

Distributed by:  Obrary, Inc.  http://obrary.com.  Obrary - democratized product design

Description:
Model of a 1700s frigate by Swedish shipbuilder Fredrik Chapman. Designed to be cut on the Laser Cutter from 3mm MDF. To assemble, each slice has a number, order them from 1 to 32 and assemble on the keel with a little sanding/glue.